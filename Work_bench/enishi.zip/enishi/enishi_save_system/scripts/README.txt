このフォルダは enishi のセーブ・復元構造体です。
・save_slots/ : 各種セーブデータ
・core_1/ : 魂・起動ログ等
・exports/ : ZIP排出済みデータ
・scripts/ : CLIテンプレート等（後で拡張可）
