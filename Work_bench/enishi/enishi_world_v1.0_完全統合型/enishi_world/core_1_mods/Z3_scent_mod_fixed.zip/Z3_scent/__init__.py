# enishi_world/Z3_scent/__init__.py

from .scent_trace import *

# または直接処理書いてもOK
# print("🎉 scent_trace 起動準備完了")
