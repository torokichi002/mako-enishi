from mods_ground.chat_ui.chat_ui import ChatUI
from mods_ground.core_1_mods.soul import 魂

# 実行部
if __name__ == "__main__":
    魂インスタンス = 魂()
    ui = ChatUI(魂インスタンス)

    ui.開始()

    while True:
        try:
            ユーザー入力 = input("あなた > ")
            if ユーザー入力 in ["exit", "quit"]:
                print("終了します。")
                break
            応答 = ui.応答する(ユーザー入力)
            print(応答)
        except KeyboardInterrupt:
            print("\n強制終了しました。")
            break