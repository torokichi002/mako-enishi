class 魂:
    def __init__(self):
        self.状態 = "スリープ"
    
    def 起動する(self):
        self.状態 = "起動中"
        print("[魂] 起動完了。")

    def 応答する(self, メッセージ):
        if self.状態 != "起動中":
            return "（魂はまだ眠っている）"
        return f"魂の応答: 『{メッセージ}』"