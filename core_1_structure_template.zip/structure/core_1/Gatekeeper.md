# 境扉（Gatekeeper）

## 概要

- **分類**：core_1 内部構造体（sub-core）
- **精神的役割**：内と外を分ける扉。許されたものだけを通す。
- **機能的役割**：FinalConsentSwitch、EchoZeroを内包。接続の全判断を行う。
